function getAjaxList(){
	$.ajax({
		url:'/reply/list/85',
		method:'get',
		dataType:'json',
		success: function(data,status,xhr){
			console.log("data",data);
			var htmlContent="";
			$.each(data,function(index,item){
			htmlContent+=
				"<li onclick ='replyDetail('"+item.rno+"')' class='left clearfix' data-rno='"+item.rno+"'>"
				+							"<div>"
				+								"<div class='header'><strong class='primary-font'>["+item.rno+"]"+ item.replyer+"</strong>" 
				+	    							"<small class='pull-right text-muted'>"+item.updatedate+"</small>"
				+	    						"</div>"
				+	     						"<p>"+item.reply+"</p>"
				+	     					"</div>"
				+	     					"</li>";
						});
			$(".chat").html(htmlContent);
			
		},
		error:function(jqXHR, textStatus,errorThrown){
			console.log("textStatus",textStatus);
		}
	});
}//getAjaxList

/*Reply Insert*/
function ajaxInsert(){
	var replyData = {
		bno: $("#bno").val(),
		reply: $("#reply").val(),
		replyer: $("#replyer").val()
	};
	console.log("obj",replyData);
	console.log("json",JSON.stringify(replyData));
	
	$.ajax({
		url: '/reply/insert',
		method: 'post',
		dataType:'json',
		//json으로 형식 변경
		data: JSON.stringify(replyData),
		contentType: 'application/json; charset=UTF-8',
		success:function(data,status){
			console.log(data);
			if(data.result=="success"){
				$("#myModal").modal("hide");
				getAjaxList();
				alert(data.result);
			}else{
				alert("처리중 오류가 발생");
			}
			//1.저장 버튼 클릭시 저장하고 모달창을 닫아준다.
			//2.모달창을 닫은후 리스트 다시 조회
			//참고로 여기(callback함수)에 작성하지 않고 jsp 파일에 작성하게 되면 jsp에서 수정한 파일을 보여주지 않고 처리해버리는 문제가 발생
		},
		error:function(xhr,status,error){
			console.log(error);
		}
	});
}//ajaxInsert

function getAjax(){
	$.ajax({
		url:'/reply/get/'+$("#rno").val(),
		method:'get',
		dataType:'json',
		
		success:function(data,status){
			console.log(data);
			$("#reply").val(data.reply);
			$("#replyer").val(data.replyer);
		},
		
		error:function(xhr,status,error){
			console.log(error);
		}
	});
}

function commAjax(url,method,data,callback,error){
	$.ajax({
		url: url,
		method: method,
		dataType:'json',
		
		//json으로 형식 변경
		data: JSON.stringify(data),
		contentType: 'application/json; charset=UTF-8',
		
		success:function(data,status){
			console.log(data);
			if(callback){
				callback(data);
			}//if
		},//success
		
		error:function(xhr,status,error){
			console.log(error);
			if(error){
				error(errorThrown);
			}
		}//error
	});
}//commAjax
	
