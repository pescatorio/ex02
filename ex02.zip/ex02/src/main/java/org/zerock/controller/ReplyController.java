package org.zerock.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;
import org.zerock.domain.ReplyVo;
import org.zerock.service.BoardService;
import org.zerock.service.ReplyService;

import jdk.internal.org.jline.utils.Log;
import lombok.extern.log4j.Log4j;

@RestController
@Log4j
public class ReplyController {
	/*
	 * @Autowired BoardService service;
	 */
	
	@Autowired
	ReplyService service;
	
	@GetMapping("/reply/get/{rno}")
	public ReplyVo get(@PathVariable("rno") int rno) {
		ReplyVo vo = service.get(rno);
		return vo;
	}
	@GetMapping("/reply/list/{bno}")
	public List<ReplyVo> getList(@PathVariable("bno")int bno) {
		List<ReplyVo> list = service.getList(bno);
		log.info(list);
		return list;
	}
	@PostMapping("/reply/insert")
	public Map<String, Object> insert(@RequestBody ReplyVo vo) {
		int res = service.insert(vo);
		log.info(res);
		Map<String, Object> map = new HashMap<String,Object>();
		if(res>0)
			map.put("result", "success");
		else
			map.put("result", "fail");
		return map;
	}
	
	/*
	 * @GetMapping("/reply/test") public BoardVO restTest() {
	 * 
	 * return service.get(120L); }
	 * 
	 * @GetMapping("/reply/test2") public ResponseEntity <List<BoardVO>>
	 * restTest2(){ Criteria cri = new Criteria(); return new
	 * ResponseEntity<List<BoardVO>>(service.getList(cri),HttpStatus.OK); }
	 * 
	 * @GetMapping("/reply/test/{pageNum}") public ResponseEntity <List<BoardVO>>
	 * restTest3(@PathVariable("pageNum") int pageNum){ Criteria cri = new
	 * Criteria(pageNum,20); return new
	 * ResponseEntity<List<BoardVO>>(service.getList(cri),HttpStatus.OK); }
	 */
	
	@GetMapping("/product/{cat}/{pid}")
	public String[]getPath(
			@PathVariable("cat") String cat, @PathVariable("pid") Integer pid
			){
		return new String[] {"category: " + cat, "productid: " +pid};
	}
}
