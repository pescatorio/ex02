package org.zerock.domain;

import lombok.Data;

@Data
public class ReplyVo {
	
	//댓글번호
	int rno;
	//게시물번호
	int bno;
	//리플
	String reply;
	//댓글작성자
	String replyer;
	//댓글 작성일
	String replydate;
	//댓글 수정일
	String updatedate;
}
