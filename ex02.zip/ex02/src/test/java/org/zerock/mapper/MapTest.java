package org.zerock.mapper;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardVO;
import org.zerock.domain.ReplyVo;

import jdk.internal.org.jline.utils.Log;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class MapTest {
	@Test
	public void MapTest1() {
		//map은 key 값에 하나씩 대응하는 value를 저장하고 필요할때 불러오는 것
		BoardVO boardvo = new BoardVO();
		boardvo.setBno(5);
		ReplyVo replyvo = new ReplyVo();
		replyvo.setRno(50);
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("boardvo", boardvo);
		map.put("replyvo",replyvo);
		log.info(map.toString());
		log.info("------------boardVo:"+map.get(boardvo));
		log.info("------------replyVo:"+map.get(replyvo));
	}
}
