package org.zerock.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.ReplyVo;
import org.zerock.mapper.ReplyMapper;
import org.zerock.service.ReplyService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class ReplyTest {
	
	@Setter(onMethod_=@Autowired)
	private ReplyMapper mapper;
	@Autowired
	ReplyService service;
	
	@Test
	public void getTotalTest() {
		log.info("==========="+mapper.getTotal(50));
	}
	
	
	@Test
	public void testMapper() {
		log.info(mapper);
	}
	
	
	
	@Test
	public void mapperInsertTest() {
		ReplyVo vo= new ReplyVo();
		vo.setBno(85);
		vo.setReply("hello reply");
		vo.setReplyer("홍길동");
		int res = mapper.insert(vo);
		log.info("======================"+res);
	}
	@Test
	public void mapperGetListTest() {
		log.info(mapper.getList(50));
	}
	@Test
	public void mapperGetTest() {
		log.info(mapper.get(1));
	}
	@Test
	public void mapperUpdateTest() {
		ReplyVo vo= new ReplyVo();
		vo.setRno(1);
		vo.setReply("수정된 reply");
		vo.setReplyer("user00");
		int res = mapper.update(vo);
		log.info("======================"+res);
	}
	@Test
	public void mapperDeleteTest() {
		log.info(mapper.delete(2));
	}
	

}
